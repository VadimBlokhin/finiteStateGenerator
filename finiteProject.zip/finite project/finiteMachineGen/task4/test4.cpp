#include <algorithm>
#include <conio.h>
#include <ctime>
#include <iostream>
#include <iterator>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <queue>
#include <vector>


using namespace std;


class Alphabet : public vector<string>
{
public:
	Alphabet(const string& alpabetStr) {
		stringstream alphabetSS(alpabetStr);
		istream_iterator<string> begin(alphabetSS);
		istream_iterator<string> end;

		for (; begin != end; begin++) {
			emplace_back(*begin);
		}
	}
};

class State : public vector< vector<int> >
{
public:
	int id;
	bool terminal;

	State(int id, bool terminal = false)
		: vector(), id(id), terminal(terminal)
	{}
	State(int id, int size, bool terminal = false)
		: vector(size), id(id), terminal(terminal)
	{}
	State(int id, const State& state)
		: vector(state), id(id), terminal(state.terminal)
	{}
	State(const State& state)
		: vector(state), id(state.id), terminal(state.terminal)
	{}
	bool operator ==(const State& state) const {
		if (this->size() != state.size()) return false;
		for (int i = 0; i < this->size(); i++) {
			if ((*this)[i] != state[i]) return false;
		}

		return true;
	}
};

class States : public vector<State*>
{
public:
	States()
		: vector()
	{}
	States(int size, int stateSize)
		: vector(size)
	{
		for (int id = 0; id < size; id++) {
			(*this)[id] = new State(id, stateSize);
		}
	}
	~States() {
		for (State* state : *this) {
			delete state;
		}
	}
};


int getMinStatesCount(int classesCount) {
	return classesCount * 2 + 2;
}

int getMaxClassesCount(int statesCount) {
	return (statesCount - 2) / 2;
}

int getRand(int begin, int end) {
	return begin + rand() % (end - begin);
}

void generateState(State& state, int stateId, bool isLoop) {
	vector<int> letters(state.size());
	for (int i = 0; i < letters.size(); i++) {
		letters[i] = i;
	}
	random_shuffle(letters.begin(), letters.end());

	if (isLoop) {
		int border = getRand(1, letters.size());

		state[letters[0]].push_back(stateId + 1);
		for (int i = 1; i < border; i++) {
			if (rand() % 2) state[letters[i]].push_back(stateId + 1);
		}

		state[letters[border]].push_back(stateId);
		for (int i = border + 1; i < letters.size(); i++) {
			if (rand() % 2) state[letters[i]].push_back(stateId);
		}
	}
	else {
		state[letters[0]].push_back(stateId + 1);
		for (int i = 1; i < letters.size(); i++) {
			if (rand() % 2) state[letters[i]].push_back(stateId + 1);
		}
	}
}

void shuffle(States& newStates, const States& oldStates) {
	int lettersCount = oldStates[0]->size();

	vector<int> oldStateIds(oldStates.size()), newStateIds(oldStates.size());
	for (State* state : oldStates) {
		oldStateIds[state->id] = state->id;
	}
	random_shuffle(oldStateIds.begin() + 1, oldStateIds.end() - 1);
	for (State* state : oldStates) {
		newStateIds[oldStateIds[state->id]] = state->id;
	}

	for (int oldStateId : oldStateIds) {
		const State& oldState = *oldStates[oldStateId];

		State* newState = new State(newStates.size(), oldState.size(), oldStates[oldStateId]->terminal);
		for (int letter = 0; letter < lettersCount; letter++) {
			for (int oldNextId : oldState[letter]) {
				(*newState)[letter].push_back(newStateIds[oldNextId]);
			}
		}
		newStates.push_back(newState);
	}
}

void generateStates(States& states, const Alphabet& alphabet, int statesCountMin, int statesCountMax, int classesCountMin, int classesCountMax) {
	cout << endl;


	statesCountMin = max(statesCountMin, getMinStatesCount(classesCountMin));

	classesCountMax = min(classesCountMax, getMaxClassesCount(statesCountMax));

	if (statesCountMin > statesCountMax || classesCountMin > classesCountMax || alphabet.size() < 2) {
		cout << "���������� ��������� ������� �� �������� ����������" << endl;
		return;
	}


	int statesCount = getRand(statesCountMin, statesCountMax + 1);

	classesCountMax = min(classesCountMax, getMaxClassesCount(statesCount));
	int classesCount = getRand(classesCountMin, classesCountMax + 1);

	cout << "������ ������� � " << statesCount << " ����������� � " << classesCount << " ��������" << endl;


	States rawStates(statesCount, alphabet.size());

	generateState(*rawStates[0], 0, false);

	for (int i = 1; i < statesCount - 1; i++) {
		if (i < classesCount * 2 + 1) {
			generateState(*rawStates[i], i + 1, true);
			rawStates[i + 1] = new State(i + 1, *rawStates[i]);
			i++;
		}
		else if (i != statesCount - 2 && rand() % 4 == 0) {
			generateState(*rawStates[i], i + 1, true);
			rawStates[i + 1] = new State(i + 1, alphabet.size(), true);
			i++;
		}
		else {
			generateState(*rawStates[i], i, rand() % 2);
		}
	}

	rawStates.back()->terminal = true;


	shuffle(states, rawStates);
}

void mimize(States& newStates, const States& oldStates) {
	int lettersCount = oldStates[0]->size();

	States prepared;
	prepared.push_back(new State(-1, lettersCount, true));
	for (State* state : oldStates) prepared.push_back(new State(*state));
	for (State* state : prepared) {
	state->id++;
	for (int& nextId : *state) nextId++;
	}
	int statesCount = prepared.size();


	States reverse(statesCount, lettersCount);
	for (State* state : reverse) state->assign(lettersCount, 0);
	for (State* state : prepared) {
	int i = state->id;
	for (int c = 0; c < lettersCount; c++) {
	int j = (*state)[c];
	(*reverse[j])[c] = i;
	}
	}


	queue< pair<int, int> > Q;
	vector< vector<bool> > marked(statesCount);
	for (vector<bool>& row : marked) row.assign(statesCount, false);

	for (int i = 0; i < statesCount; i++) {
	for (int j = 0; j < statesCount; j++) {
	if (!marked[i][j] && prepared[i]->terminal != prepared[j]->terminal) {
	marked[i][j] = marked[j][i] = true;
	Q.push(make_pair(i, j));
	}
	}
	}

	while (!Q.empty()) {
	int u = Q.front().first;
	int v = Q.front().second;
	Q.pop();

	for (int c = 0; c < lettersCount; c++) {
	int r = (*reverse[u])[c];
	int s = (*reverse[v])[c];
	if (!marked[r][s]) {
	marked[r][s] = marked[s][r] = true;
	Q.push(make_pair(r, s));
	}
	}
	}


	vector<int> component(statesCount, -1);
	for (int i = 0; i < statesCount; i++) {
	if (!marked[0][i]) {
	component[i] = 0;
	}
	}

	int componentsCount = 0;
	for (int i = 1; i < statesCount; i++) {
	if (component[i] == -1) {
	componentsCount++;
	component[i] = componentsCount;
	for (int j = i + 1; j < statesCount; j++) {
	if (!marked[i][j]) component[j] = componentsCount;
	}
	}
	}


	for (auto& row : marked) {
	for (int i : row) {
	cout << i << " ";
	}
	cout << endl;
	}
}

void print(const States& states, const Alphabet& alphabet, const string& name) {
	cout << endl;
	cout << string(alphabet.size() * 8 + 9, '=') << endl;
	cout << "  " << name << endl;
	cout << string(alphabet.size() * 8 + 9, '=') << endl;

	cout << "\t|";
	for (const string& letter : alphabet) {
		cout << " " << letter << "\t|";
	}
	cout << endl;

	cout << string(alphabet.size() * 8 + 9, '-') << endl;

	for (State* state : states) {
		if (state->id == 0) {
			cout << " >s" << state->id << "\t|";
		}
		else if (state->terminal) {
			cout << " {s" << state->id << "}\t|";
		}
		else {
			cout << "  s" << state->id << "\t|";
		}

		for (const vector<int>& next : *state) {
			if (!next.empty()) {
				cout << " s" << next[0] << "\t|";
			}
			else {
				cout << "\t|";
			}
		}

		cout << endl;
	}

	cout << endl;
}


void main() {
	setlocale(LC_ALL, "ru-RU");
	srand(time(NULL));


	string alpabetStr;
	cout << "������� �������, ����������� ��������� - ������: ";
	getline(cin, alpabetStr);
	Alphabet alphabet(alpabetStr);

	int statesCountMin, statesCountMax;
	cout << "������� ����������� � ������������ ���������� ���������: ";
	cin >> statesCountMin >> statesCountMax;

	int classesCountMin, classesCountMax;
	cout << "������� ����������� � ������������ ���������� ������� �������������� �� ��������� ���������: ";
	cin >> classesCountMin >> classesCountMax;


	States states;
	generateStates(states, alphabet, statesCountMin, statesCountMax, classesCountMin, classesCountMax);
	print(states, alphabet, "DFA");

	States minimized;
	mimize(minimized, states);
	print(minimized, alphabet, "DFA M'");


	cout << "������� ����� ������� ��� ������...";
	_getch();
}