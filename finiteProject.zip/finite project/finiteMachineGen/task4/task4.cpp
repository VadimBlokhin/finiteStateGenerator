#include <algorithm>
#include <conio.h>
#include <ctime>
#include <iostream>
#include <iterator>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <queue>
#include <vector>


using namespace std;


int getMinStatesCount(int classesCount) {
	return classesCount * 2 + 2;
}

int getMaxClassesCount(int statesCount) {
	return (statesCount - 2) / 2;
}

int getRand(int begin, int end) {
	return begin + rand() % (end - begin);
}


class Alphabet : public vector<string>
{
public:
	Alphabet(const string& alpabetStr) {
		stringstream alphabetSS(alpabetStr);
		istream_iterator<string> begin(alphabetSS);
		istream_iterator<string> end;

		for (; begin != end; begin++) {
			emplace_back(*begin);
		}
	}
};


class State : public vector< vector<int> >
{
public:
	int id;
	bool terminal;

	State(int id, bool terminal = false)
		: vector(), id(id), terminal(terminal)
	{}
	State(int id, int size, bool terminal = false)
		: vector(size), id(id), terminal(terminal)
	{}
	State(int id, const State& state)
		: vector(state), id(id), terminal(state.terminal)
	{}
	State(const State& state)
		: vector(state), id(state.id), terminal(state.terminal)
	{}

	bool operator ==(const State& state) const {
		if (size() != state.size()) return false;
		for (int i = 0; i < size(); i++) {
			if ((*this)[i] != state[i]) return false;
		}

		return true;
	}

	void generate(int nextId1, int nextId2, int nextId3) {
		vector<int> letters(size());
		for (int i = 0; i < letters.size(); i++) {
			letters[i] = i;
		}
		random_shuffle(letters.begin(), letters.end());

		int nextBorder1 = 0;
		if (nextId1 != nextId2) {
			nextBorder1 = getRand(1, letters.size() - 1);
			(*this)[letters[0]].push_back(nextId1);
			for (int i = 1; i < nextBorder1; i++) {
				if (rand() % 2) (*this)[letters[i]].push_back(nextId1);
			}
		}

		int nextBorder2 = nextBorder1;
		if (nextId2 != nextId3) {
			nextBorder2 = getRand(nextBorder1 + 1, letters.size());
			(*this)[letters[nextBorder1]].push_back(nextId2);
			for (int i = nextBorder1 + 1; i < nextBorder2; i++) {
				if (rand() % 2) (*this)[letters[i]].push_back(nextId2);
			}
		}

		(*this)[letters[nextBorder2]].push_back(nextId3);
		for (int i = nextBorder2 + 1; i < letters.size(); i++) {
			if (rand() % 2) (*this)[letters[i]].push_back(nextId3);
		}
	}

	void generate(int nextId1, int nextId2) {
		generate(nextId1, nextId1, nextId2);
	}

	void generate(int nextId) {
		generate(nextId, nextId);
	}

	void replaceNextId(int newNextId, int oldNextId, bool random = false) {
		for (vector<int>& next : *this) {
			for (int& nextId : next) {
				if (nextId == oldNextId && (!random || rand() % 2)) nextId = newNextId;
			}
		}
	}
};


class States : public vector<State*>
{
public:
	States()
		: vector()
	{}
	States(int size, int stateSize)
		: vector(size)
	{
		for (int id = 0; id < size; id++) {
			(*this)[id] = new State(id, stateSize);
		}
	}
	~States() {
		for (State* state : *this) {
			delete state;
		}
	}
};


void generateClass(States& states, int& stateId, int& classId, int statesCount, int classesCount, bool child = false) {
	int maxSize = (statesCount - stateId - 1) - (classesCount - classId) * 2 + 1;

	if (maxSize >= 4 && classId <= classesCount - 2 && rand() % 2) {
		states[stateId]->generate(stateId + 1, stateId + 2);

		states[stateId + 1] = new State(stateId + 1, *states[stateId]);
		states[stateId + 1]->replaceNextId(stateId + 3, stateId + 2);

		stateId += 2;
		classId++;

		generateClass(states, stateId, classId, statesCount, classesCount, true);
	} else if (child && rand() % 2) {
		states[stateId]->generate(stateId, stateId + 2);

		states[stateId + 1] = new State(stateId + 1, *states[stateId]);
		states[stateId + 1]->replaceNextId(stateId + 1, stateId);

		stateId++;
	} else {
		int size = getRand(1, min(maxSize, 2) + 1);

		switch (size) {
			case 1:
				states[stateId]->generate(stateId + 1, stateId + 2);
				break;

			case 2:
				states[stateId]->generate(stateId + 1, stateId + 2, stateId + 3);
				break;
		}

		for (int i = 0; i < size; i++) {
			states[stateId + i + 1] = new State(stateId + i + 1, *states[stateId]);
			for (int j = 0; j < size; j++) {
				states[stateId + i + 1]->replaceNextId(stateId + i + 1, stateId + j + 1, true);
			}
		}

		stateId += size;
	}
}

void generateTerminal(States& states, int& stateId) {
	states[stateId]->generate(stateId, stateId + 1, stateId + 2);
	states[stateId + 1] = new State(stateId + 1, states[stateId + 1]->size(), true);
	stateId++;
}

void shuffle(States& newStates, const States& oldStates) {
	int lettersCount = oldStates[0]->size();

	vector<int> oldStateIds(oldStates.size()), newStateIds(oldStates.size());
	for (State* state : oldStates) {
		oldStateIds[state->id] = state->id;
	}
	random_shuffle(oldStateIds.begin() + 1, oldStateIds.end());
	for (State* state : oldStates) {
		newStateIds[oldStateIds[state->id]] = state->id;
	}

	for (int oldStateId : oldStateIds) {
		const State* oldState = oldStates[oldStateId];

		State* newState = new State(newStates.size(), oldState->size(), oldStates[oldStateId]->terminal);
		for (int letter = 0; letter < lettersCount; letter++) {
			for (int oldNextId : (*oldState)[letter]) {
				(*newState)[letter].push_back(newStateIds[oldNextId]);
			}
		}
		newStates.push_back(newState);
	}
}

void generateStates(States& states, const Alphabet& alphabet, int statesCountMin, int statesCountMax, int classesCountMin, int classesCountMax) {
	cout << endl;


	statesCountMin = max(statesCountMin, getMinStatesCount(classesCountMin));

	classesCountMax = min(classesCountMax, getMaxClassesCount(statesCountMax));

	if (statesCountMin > statesCountMax || classesCountMin > classesCountMax || alphabet.size() < 3) {
		cout << "���������� ��������� ������� �� �������� ����������" << endl;
		return;
	}


	int statesCount = getRand(statesCountMin, statesCountMax + 1);

	classesCountMax = min(classesCountMax, getMaxClassesCount(statesCount));
	int classesCount = getRand(classesCountMin, classesCountMax + 1);

	cout << "������ ������� � " << statesCount << " ����������� � " << classesCount << " ��������" << endl;


	States rawStates(statesCount, alphabet.size());

	rawStates.front()->generate(1);

	int classId = 0;
	for (int stateId = 1; stateId < statesCount - 1; stateId++) {
		if (classId < classesCount - 1) {
			generateClass(rawStates, stateId, classId, statesCount - 2, classesCount - 1);
			classId++;
		} else if (classId == classesCount - 1) {
			generateTerminal(rawStates, stateId);
			classId++;
		} else if (classesCount && stateId < statesCount - 2 && rand() % 4 == 0) {
			generateTerminal(rawStates, stateId);
		} else {
			if (rand() % 2) {
				rawStates[stateId]->generate(stateId, stateId + 1);
			} else {
				rawStates[stateId]->generate(stateId + 1);
			}
		}
	}

	rawStates.back()->terminal = true;


	shuffle(states, rawStates);
}

void mimize(States& newStates, const States& oldStates) {
	int lettersCount = oldStates[0]->size();

	States prepared;
	prepared.push_back(new State(-1, lettersCount));
	for (State* state : oldStates) prepared.push_back(new State(*state));
	for (State* state : prepared) {
		for (vector<int>& next : *state) {
			if (next.empty()) next.push_back(-1);
		}
	}
	for (State* state : prepared) {
		state->id++;
		for (vector<int>& next : *state) {
			for (int& nextId : next) nextId++;
		}
	}
	int statesCount = prepared.size();


	States reverse(statesCount, lettersCount);
	for (State* state : prepared) {
		int i = state->id;
		for (int c = 0; c < lettersCount; c++) {
			for (int j : (*state)[c]) {
				(*reverse[j])[c].push_back(i);
			}
		}
	}


	queue< pair<int, int> > Q;
	vector< vector<bool> > marked(statesCount);
	for (vector<bool>& row : marked) row.assign(statesCount, false);

	for (int i = 0; i < statesCount; i++) {
		for (int j = 0; j < statesCount; j++) {
			if (!marked[i][j] && prepared[i]->terminal != prepared[j]->terminal) {
				marked[i][j] = marked[j][i] = true;
				Q.push(make_pair(i, j));
			}
		}
	}

	while (!Q.empty()) {
		int u = Q.front().first;
		int v = Q.front().second;
		Q.pop();

		for (int c = 0; c < lettersCount; c++) {
			for (int r : (*reverse[u])[c]) {
				for (int s : (*reverse[v])[c]) {
					if (!marked[r][s]) {
						marked[r][s] = marked[s][r] = true;
						Q.push(make_pair(r, s));
					}
				}
			}
		}
	}


	vector<int> component(statesCount, -1);
	for (int i = 0; i < statesCount; i++) {
		if (!marked[0][i]) {
			component[i] = 0;
		}
	}

	int componentsCount = 0;
	for (int i = 1; i < statesCount; i++) {
		if (component[i] == -1) {
			componentsCount++;
			component[i] = componentsCount;
			for (int j = i + 1; j < statesCount; j++) {
				if (!marked[i][j]) component[j] = componentsCount;
			}
		}
	}


	int current = 1;
	for (int i = 1; i < statesCount; i++) {
		State* oldState = prepared[i];
		if (component[oldState->id] == current) {
			State* newState = new State(newStates.size(), oldState->size(), oldState->terminal);
			for (int letter = 0; letter < lettersCount; letter++) {
				for (int oldNextId : (*oldState)[letter]) {
					int newNextId = component[oldNextId] - 1;
					if (newNextId >= 0) (*newState)[letter].push_back(newNextId);
				}
			}
			newStates.push_back(newState);

			current++;
		}
	}
}

void print(const States& states, const Alphabet& alphabet, const string& name) {
	cout << endl;
	cout << string(alphabet.size() * 8 + 9, '=') << endl;
	cout << "  " << name << endl;
	cout << string(alphabet.size() * 8 + 9, '=') << endl;

	cout << "\t|";
	for (const string& letter : alphabet) {
		cout << " " << letter << "\t|";
	}
	cout << endl;

	cout << string(alphabet.size() * 8 + 9, '-') << endl;

	for (State* state : states) {
		if (state->id == 0) {
			cout << " >s" << state->id << "\t|";
		} else if (state->terminal) {
			cout << " {s" << state->id << "}\t|";
		} else {
			cout << "  s" << state->id << "\t|";
		}

		for (const vector<int>& next : *state) {
			for (int i = 0; i < next.size(); i++) {
				if (i) cout << ",";
				cout << " s" << next[i];
			}
			cout << "\t|";
		}

		cout << endl;
	}

	cout << endl;
}


void main() {
	setlocale(LC_ALL, "ru-RU");
	srand(time(NULL));


	string alpabetStr;
	cout << "������� �������, ����������� - ������, ����������� ���������� - 3: ";
	getline(cin, alpabetStr);
	Alphabet alphabet(alpabetStr);

	int statesCountMin, statesCountMax;
	cout << "������� ����������� � ������������ ���������� ���������: ";
	cin >> statesCountMin >> statesCountMax;

	int classesCountMin, classesCountMax;
	cout << "������� ����������� � ������������ ���������� ������� �������������� �� ��������� ���������: ";
	cin >> classesCountMin >> classesCountMax;


	States states;
	generateStates(states, alphabet, statesCountMin, statesCountMax, classesCountMin, classesCountMax);
	print(states, alphabet, "DFA");

	States minimized;
	mimize(minimized, states);
	print(minimized, alphabet, "DFA M'");


	cout << "������� ����� ������� ��� ������...";
	_getch();
}